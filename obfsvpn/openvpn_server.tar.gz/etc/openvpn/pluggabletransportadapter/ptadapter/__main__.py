from . import console_script

if __name__ == '__main__':
    console_script.main()
